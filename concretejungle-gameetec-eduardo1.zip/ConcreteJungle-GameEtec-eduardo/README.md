# Nome do Jogo
Projeto do Gamemaker para a ETEC sobre um sapo humanoide.


# Branchs:
- Main - Projeto **ESTÁVEL** com todas as alterações

- Iago - alterações minhas (@ImFenyx)

- Caio - alterações do Caio

- Eduardo - alterações do Eduardo

- Luara - alterações da Luara

- Testing - Projeto com todas as alterações sendo testado, corrigido e polido
